#include <stdio.h>
#include <unistd.h>
#include <string.h>
#define HOST_MAX_LEN 255 // defines the max host length

void PrintTokens (const char** tokens);
char** ReadTokens (FILE* stream);
void FreeTokens (char** tokens);


int main()
{
/*
char hostname[HOST_MAX_LEN];
char * login;
gethostname(student, sizeof student);
login=getlogin();
*/

while(1)
{
	//printf("%s@%s$ ",name, host);
	char ** toks =  ReadTokens(stdin);
	if(toks == NULL)
	{
		exit(-1);
	}
        PrintTokens(toks);
	FreeTokens(toks);
}




}
//---------- compiling ----------//
char** ReadTokens(FILE* stream)
{
const char seprator = ' ';
char data [510];
char ** tok;
const char* quit = "quit";
fgets(data,sizeof(data),stream);

if(data==NULL)
{
    return NULL;
}

if(data[0]=='\n' || data[0]=='\0' )
{
    return NULL;
}

char temp[510];
strcpy(temp,data);
temp[strlen(temp)-1]='\0';
data[strlen(data)-1]='\0';


int n=0;
char * first = strtok(temp," ");
int rc = strcmp(first,quit);
    if(rc == 0)
	return 0;
while(first !=NULL)
{      n++;

     first = strtok(NULL," ");
     /*if( first !=NULL && (first==' '|| first[0]=='\n'))
     {
         n--;
     }*/

}


tok = (char**)malloc((n+1)*sizeof(char*));
if(tok ==NULL)
{
    exit(-1);
}

int i =0;
tok[i]= strtok(data," ");

if(tok[i] !=' ')
{
i++;
}
for(;i<n;)
{

    tok[i]=(char**)malloc((n+1)*sizeof(char*));
    tok[i]=strtok(NULL," ");
    if(tok[i] !=' ')
    {
        i++;
    }
}

      tok[n]=NULL;
     


return tok;
}
//---------- print----------//
void PrintTokens(const char** tokens)
{

	int i=0;
	while(tokens[i] != NULL)
	{
		printf("%s\n",tokens[i]);
		i++;
	}

}
//---------- free ----------//
void FreeTokens(char** tokens)
{
	int i = 0;
	while(tokens[i] != NULL)
	{
		free(tokens[i]);
		i++;
	}
	free(tokens);

}



